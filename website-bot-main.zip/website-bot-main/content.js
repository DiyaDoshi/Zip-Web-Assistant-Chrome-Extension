(function() {
    let button = document.createElement("button");
    // button.innerText = "Chat";
    // button.style.position = "fixed";
    // button.style.bottom = "20px";
    // button.style.right = "20px";
    // button.style.zIndex = "1000";
    // button.style.background = "blue";
    // button.style.color = "white";
    // button.style.border = "none";
    // button.style.padding = "10px 20px";
    // button.style.borderRadius = "5px";
    // button.style.cursor = "pointer";
    // document.body.appendChild(button);

    button.classList.add("extension-button");

    // Create an image element
    let iconImage = document.createElement("img");
    iconImage.src = chrome.runtime.getURL("icons/web.svg"); // Correct path
    iconImage.alt = "Web Assistant";

    // Append the image inside the button
    button.appendChild(iconImage);

    // Apply styles to button
    button.style.position = "fixed";
    button.style.bottom = "150px";
    button.style.right = "1px";
    button.style.zIndex = "1000";
    button.style.border = "none";
    button.style.background = "transparent";
    button.style.padding = "0";
    button.style.borderRadius = "5px"
    button.style.padding = "10px 20px";
    button.style.cursor = "pointer";

    // Apply styles to image
    iconImage.style.width = "55px";
    iconImage.style.height = "55px";
    iconImage.style.backgroundColor = "#ebccff";
    iconImage.style.borderRadius = "50%";
    iconImage.style.padding = "3px";
    iconImage.style.objectFit = "contain";
    iconImage.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
    iconImage.style.transition = "background-color 0.3s ease, transform 0.3s ease";

    document.body.appendChild(button);
    
    button.addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "scrapeWebsite", url: window.location.href }, (response) => {
            console.log("Scraping Response:", response);
            if (response.status === "success") {
                // let iframe = document.createElement("iframe");
                // iframe.src = chrome.runtime.getURL("popup.html");
                // iframe.style.position = "fixed";
                // iframe.style.bottom = "70px";
                // iframe.style.right = "20px";
                // iframe.style.width = "350px";
                // iframe.style.height = "400px";
                // iframe.style.zIndex = "999";
                // iframe.style.border = "1px solid #ccc";
                // iframe.style.background = "white";
                // iframe.style.overflow = "hidden";
                // iframe.style.padding = "0px";
                // iframe.style.borderRadius = "10px";
                // iframe.style.scrolling = "no";
                // document.body.appendChild(iframe);
                // Create new chat window
                const chatWindow = document.createElement("div");
                chatWindow.id = "chatWindow";
                chatWindow.style.position = "fixed";
                chatWindow.style.bottom = "70px";  // Adjusted to accommodate button
                chatWindow.style.right = "20px";
                chatWindow.style.width = "350px";
                chatWindow.style.height = "400px";
                chatWindow.style.background = "white";
                chatWindow.style.border = "1px solid #ccc";
                // chatWindow.style.boxShadow = "0px 4px 6px rgba(0,0,0,0.1)";
                chatWindow.style.zIndex = "999";
                chatWindow.style.overflow = "hidden";
                chatWindow.style.padding = "0px";
                chatWindow.style.borderRadius = "10px";
                chatWindow.style.scrolling = "no";

                // Create iframe for chat content
                const iframe = document.createElement("iframe");
                iframe.width = "100%";
                iframe.height = "400px";
                iframe.src = chrome.runtime.getURL("popup.html");
                iframe.frameBorder = "0";
                iframe.style.cssText = "overflow: hidden; scrolling: no;";
    

                // Create close button
                const closeButton = document.createElement("button");
                closeButton.textContent = "×";
                closeButton.style.position = "absolute";
                closeButton.style.top = "5px";
                closeButton.style.right = "5px";
                closeButton.style.background = "#6a0dad";
                closeButton.style.color = "white";
                closeButton.style.border = "none";
                closeButton.style.padding = "5px 10px";
                closeButton.style.cursor = "pointer";
                closeButton.style.borderRadius = "3px";

                closeButton.onclick = () => {
                    chatWindow.remove();
                    button.style.display = "block"; 
                };

                chatWindow.appendChild(closeButton);
                chatWindow.appendChild(iframe);
                document.body.appendChild(chatWindow);

            }
            button.style.display = "none";
        });

         
    });

    

})();
