// document.getElementById("send").addEventListener("click", () => {
//     let userInput = document.getElementById("userInput").value;
//     if (userInput.trim() === "") return;
    
//     let chatbox = document.getElementById("chatbox");
//     chatbox.innerHTML += `<div><strong>You:</strong> ${userInput}</div>`;
//     document.getElementById("userInput").value = "";
    
//     fetch("http://127.0.0.1:8080/chat", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ tenant_id: "user", message: userInput })
//     })
//     .then(response => response.json())
//     .then(data => {
//         chatbox.innerHTML += `<div><strong>Bot:</strong> ${data.response}</div>`;
//         chatbox.scrollTop = chatbox.scrollHeight;
//     });
// });





class ChatManager {
    constructor() {
        this.chatBox = document.getElementById('chatbox');
        this.userInput = document.getElementById('userInput');
        this.conversationId = null;
        this.initializeEventListeners();
        this.loadConversationId(); // Only load conversation ID, not chat history
    }

   

    initializeEventListeners() {
        document.getElementById('send').addEventListener('click', () => this.sendMessage());
        this.userInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                this.sendMessage();
            }
        });

        

        // Listen for messages from content script
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.type === "chatbotResponse") {
                this.displayMessage(message.content, false);
            }
        });
        
        // Focus the input field when popup opens
        this.userInput.focus();
    }

    displayMessage(message, isUser) {
        // First, remove any existing typing indicator
        this.removeTypingIndicator();
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user' : 'bot'}`;
        messageDiv.innerHTML = `<strong>${isUser ? 'You' : 'Bot'}:</strong> ${message}`;
        this.chatBox.appendChild(messageDiv);
        this.scrollToBottom();
    }
    
    showTypingIndicator() {
        // Remove any existing typing indicator first
        this.removeTypingIndicator();
        
        const indicator = document.createElement('div');
        indicator.className = 'typing-indicator';
        indicator.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        this.chatBox.appendChild(indicator);
        this.scrollToBottom();
    }
    
    removeTypingIndicator() {
        const existingIndicator = this.chatBox.querySelector('.typing-indicator');
        if (existingIndicator) {
            existingIndicator.remove();
        }
    }
    
    scrollToBottom() {
        this.chatBox.scrollTop = this.chatBox.scrollHeight;
    }

    async sendMessage() {
        const userInput = this.userInput.value.trim();
        if (!userInput) return;

        // Display user message
        this.displayMessage(userInput, true);
        this.userInput.value = "";
        
        // Show typing indicator
        this.showTypingIndicator();

      

        try {
            const response = await fetch("https://website-bot-86sj.onrender.com/chat", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: userInput,
                    tenant_id: "user"
                }),
            });

            const data = await response.json();
            
            // // Remove typing indicator
            // this.removeTypingIndicator();
            
            // Store the conversation ID from the response
            if (data.conversation_id) {
                this.conversationId = data.conversation_id;
                // Save state after getting new conversation ID
                this.saveState();
            }

            // // Display bot response
            // this.displayMessage(data.response, false);
            
            // // Save state after each message
            // this.saveState();

            // Remove typing indicator and display bot response
            setTimeout(() => {
                this.removeTypingIndicator();
                this.displayMessage(data.response, false);
            }, 500); // Small delay to make the transition smoother
            
            // Save state after each message
            this.saveState();

        } catch (error) {
            // Remove typing indicator
            this.removeTypingIndicator();
            
            console.error('Error:', error);
            this.displayMessage('Sorry, something went wrong.', false);
        }
    }

    loadConversationId() {
        chrome.storage.local.get(['conversationId'], (result) => {
            if (result.conversationId) {
                this.conversationId = result.conversationId;
                console.log('Loaded conversation ID:', this.conversationId);
            }
        });
    }

    saveState() {
        const state = {
            conversationId: this.conversationId
        };
        chrome.storage.local.set(state, () => {
            console.log('Conversation ID saved');
        });
    }

    addTypingIndicatorStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .typing-indicator {
                padding: 10px 14px;
                max-width: 80px;
            }
            
            .typing-dots {
                display: flex;
                gap: 4px;
            }
            
            .typing-dot {
                width: 8px;
                height: 8px;
                background-color: #999;
                border-radius: 50%;
                animation: typingBounce 1.3s infinite ease;
            }
            
            .typing-dot:nth-child(2) {
                animation-delay: 0.15s;
            }
            
            .typing-dot:nth-child(3) {
                animation-delay: 0.3s;
            }
            
            @keyframes typingBounce {
                0%, 60%, 100% {
                    transform: translateY(0);
                }
                30% {
                    transform: translateY(-4px);
                }
            }
        `;
        document.head.appendChild(style);
    }

    
    
}

// Initialize chat manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const chatManager = new ChatManager();

    // Save state when popup is closed
    window.addEventListener('beforeunload', () => {
        chatManager.saveState();
    });
});
